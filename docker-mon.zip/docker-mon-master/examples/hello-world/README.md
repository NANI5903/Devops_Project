# hello-world

This example shows how the `hello-world` container can be cleaned up by `mon`, when it exits with code `0` (which is it's default behavior).

```
# Specify --build to ensure mon is rebuilt
docker-compose up --build
```
